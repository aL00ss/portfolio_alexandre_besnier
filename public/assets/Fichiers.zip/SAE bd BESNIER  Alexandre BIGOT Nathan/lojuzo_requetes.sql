
SELECT materiel.CodeMateriel
FROM materiel
JOIN Fournisseur ON materiel.numFourn = Fournisseur.numFourn 
WHERE Fournisseur.nomFour = "SIREX SA"


INSERT INTO `panne` (`noPanne`,`datePanne`,`nature`,`CodeMateriel`) 
VALUES (5,'2023-02-13','Moteur principal','B0126')


SELECT CodeMateriel 
FROM materiel
WHERE dateAchat > "2020-12-31" AND dateAchat <= "2021-12-31"


SELECT * 
FROM panne 
ORDER BY Montant DESC


UPDATE panne 
SET montant = (SELECT PrixAchat FROM materiel WHERE CodeMateriel = "B0126")*0.10,
dateReparation = "2023-02-13" 
WHERE CodeMateriel = "B0126" AND datePanne = "2023-02-13"


CREATE TABLE LISTE_PANNES AS 
SELECT YEAR(dateReparation) AS annee, Fournisseur.nomFour AS fournisseur, COUNT(*) AS nb_reparations 
FROM panne 
JOIN Fournisseur ON panne.numFourn = Fournisseur.numFourn 
WHERE dateReparation IS NOT NULL 
GROUP BY YEAR(dateReparation), Fournisseur.nomFour 
ORDER BY YEAR(dateReparation), nb_reparations DESC


SELECT CodeMateriel 
FROM materiel
WHERE DureeGarantie IS NULL



SELECT Centre.NomCentre, COUNT(*) as nb_pannes 
FROM panne 
JOIN materiel ON materiel.CodeMateriel = panne.CodeMateriel 
JOIN Centre ON materiel.CodeCentreUtilisateur = Centre.CodeCentre 
GROUP BY Centre.CodeCentre 
ORDER BY nb_pannes DESC



SELECT Famille.NomFamille, AVG(Outils.PrixAchat) as prix_moyen 
FROM materiel
JOIN Famille ON materiel.CodeFamille = Famille.CodeFamille 
GROUP BY Famille.CodeFamille 
ORDER BY prix_moyen DESC