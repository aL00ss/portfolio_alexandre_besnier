-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 03 mars 2023 à 20:49
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `lojuzo`
--

-- --------------------------------------------------------

--
-- Structure de la table `centre`
--

CREATE TABLE `centre` (
  `CodeCentre` varchar(50) NOT NULL,
  `NomCentre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `centre`
--

INSERT INTO `centre` (`CodeCentre`, `NomCentre`) VALUES
('AD', 'Administratif'),
('DE', 'Découpe'),
('MO', 'Montage'),
('SC', 'Scillage');

-- --------------------------------------------------------

--
-- Structure de la table `famille`
--

CREATE TABLE `famille` (
  `CodeFamille` int(11) NOT NULL,
  `NomFamille` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `famille`
--

INSERT INTO `famille` (`CodeFamille`, `NomFamille`) VALUES
(1, 'Ponceuses'),
(2, 'Raboteuses'),
(3, 'Fraiseuses'),
(4, 'Bureautique');

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

CREATE TABLE `fournisseur` (
  `numFourn` int(11) NOT NULL,
  `nomFour` varchar(50) DEFAULT NULL,
  `telFour` int(11) DEFAULT NULL,
  `rueFour` varchar(50) DEFAULT NULL,
  `cpFour` int(11) DEFAULT NULL,
  `villeFour` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `fournisseur`
--

INSERT INTO `fournisseur` (`numFourn`, `nomFour`, `telFour`, `rueFour`, `cpFour`, `villeFour`) VALUES
(4010123, 'SIREX SA', 436637823, ' 23 rue du sabot', 71390, 'Ste Hélène'),
(4010245, 'POTTIN', 559263158, 'Zone artisanale des Mottins', 33000, 'Bordeaux'),
(4010270, 'ESPACE INFORMATIQUE', 549774536, '290 Avenue de Paris', 79000, 'Niort'),
(4010381, 'SORAM', 546721345, '15 rue des acacias', 86000, 'Poitiers'),
(4010420, 'INFOXPRESS', 546000335, 'ZA des marots', 17000, 'La Rochelle'),
(4010555, 'PINOZ', 549010378, 'Espace Mendès France', 79000, 'Niort'),
(4010577, 'REPARA\'BOIS', 549012399, 'ZA des maronniers', 79000, 'Niort');

-- --------------------------------------------------------

--
-- Structure de la table `liste_pannes`
--

CREATE TABLE `liste_pannes` (
  `annee` int(4) DEFAULT NULL,
  `fournisseur` varchar(50) DEFAULT NULL,
  `nb_reparations` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `liste_pannes`
--

INSERT INTO `liste_pannes` (`annee`, `fournisseur`, `nb_reparations`) VALUES
(2022, 'SIREX SA', 1),
(2022, 'POTTIN', 1);

-- --------------------------------------------------------

--
-- Structure de la table `materiel`
--

CREATE TABLE `materiel` (
  `CodeMateriel` varchar(50) NOT NULL,
  `NomMateriel` varchar(50) DEFAULT NULL,
  `PrixAchat` double DEFAULT NULL,
  `DateAchat` datetime DEFAULT NULL,
  `DureeGarantie` int(11) DEFAULT NULL,
  `CodeFamille` int(11) NOT NULL,
  `numFourn` int(11) NOT NULL,
  `CodeCentre` varchar(50) NOT NULL,
  `CodeCentreUtilisateur` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `materiel`
--

INSERT INTO `materiel` (`CodeMateriel`, `NomMateriel`, `PrixAchat`, `DateAchat`, `DureeGarantie`, `CodeFamille`, `numFourn`, `CodeCentre`, `CodeCentreUtilisateur`) VALUES
('B0123', 'SCHOB 3852', 6895, '2022-01-12 00:00:00', 2, 2, 4010123, 'DE', 'DE, MO'),
('B0126', 'MILANO 4256', 8030, '2022-02-05 00:00:00', 4, 3, 4010245, 'DE', 'DE'),
('B0129', 'MILANO 4276', 9887, '2022-11-05 00:00:00', 4, 3, 4010245, 'DE', 'DE'),
('BO003', 'Makita 2340', 1230, '2018-01-05 00:00:00', 2, 2, 4010123, 'DE', 'DE,DE,MO'),
('BO053', 'HBM BF 60', 6700, '2018-11-21 00:00:00', 3, 3, 4010555, 'DE', 'DE,DE'),
('BO072', 'Photocopieur Canon ZS PO', 2190, '2019-01-06 00:00:00', 2, 4, 4010381, 'AD', 'AD,AD,DE,MO,SC'),
('BO091', 'Makita 3567', 1987, '2019-12-08 00:00:00', 2, 2, 4010123, 'DE', 'DE,DE'),
('BO097', 'Serveur Dell PowerEdge R550 Serveur Rack', 3395, '2021-02-02 00:00:00', 2, 4, 4010420, 'AD', 'AD,AD'),
('BO099', 'Columbus Mod. 145 SH', 1545, '2021-04-03 00:00:00', 2, 1, 4010555, 'MO', 'MO,MO,SC,DE'),
('BO111', 'Imprimante Canon ZD46', 450, '2021-04-18 00:00:00', 1, 4, 4010270, 'AD', 'AD,AD'),
('BO113', 'Festool LHS-E 225/CTM36-Set', 1830, '2021-05-25 00:00:00', 2, 1, 4010123, 'MO', 'MO,MO'),
('BO115', 'Os à gros débit - SX200', 2100, '2021-06-12 00:00:00', 3, 2, 4010123, 'SC', 'SC,SC,MO');

-- --------------------------------------------------------

--
-- Structure de la table `panne`
--

CREATE TABLE `panne` (
  `noPanne` int(11) NOT NULL,
  `CodeMateriel` varchar(50) NOT NULL,
  `datePanne` datetime NOT NULL,
  `nature` varchar(50) NOT NULL,
  `dateReparation` datetime DEFAULT NULL,
  `numFourn` int(11) DEFAULT NULL,
  `montant` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `panne`
--

INSERT INTO `panne` (`noPanne`, `CodeMateriel`, `datePanne`, `nature`, `dateReparation`, `numFourn`, `montant`) VALUES
(1, 'B0123', '2022-05-05 00:00:00', 'Lame', '2022-05-12 00:00:00', 4010123, 25),
(2, 'B0123', '2022-10-10 00:00:00', 'Courroie', '2022-11-23 00:00:00', 4010245, 296),
(4, 'BO003', '2019-01-12 00:00:00', 'Vis de serrage défectueux', '2020-02-12 00:00:00', 4010577, 45),
(5, 'B0126', '2023-02-13 00:00:00', 'Moteur principal', '2023-02-13 00:00:00', NULL, 803),
(6, 'BO003', '2021-12-12 00:00:00', 'Poignée', '2021-12-15 00:00:00', 4010577, 80),
(7, 'BO053', '2021-12-20 00:00:00', 'Table de travail', '2021-01-15 00:00:00', 4010555, 620),
(8, 'BO097', '2021-02-24 00:00:00', 'Ventilateur', '2021-02-26 00:00:00', 4010420, 550),
(9, 'BO099', '2021-11-21 00:00:00', 'Brosse', '2021-12-10 00:00:00', 4010123, 325),
(10, 'BO111', '2021-06-20 00:00:00', 'Toner', '2021-06-20 00:00:00', 4010555, 75),
(11, 'BO115', '2021-12-15 00:00:00', 'Lame', '2021-12-16 00:00:00', 4010123, 39);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `centre`
--
ALTER TABLE `centre`
  ADD PRIMARY KEY (`CodeCentre`);

--
-- Index pour la table `famille`
--
ALTER TABLE `famille`
  ADD PRIMARY KEY (`CodeFamille`);

--
-- Index pour la table `fournisseur`
--
ALTER TABLE `fournisseur`
  ADD PRIMARY KEY (`numFourn`);

--
-- Index pour la table `materiel`
--
ALTER TABLE `materiel`
  ADD PRIMARY KEY (`CodeMateriel`),
  ADD KEY `numFourn` (`numFourn`),
  ADD KEY `CodeCentre` (`CodeCentre`),
  ADD KEY `CodeFamille` (`CodeFamille`);

--
-- Index pour la table `panne`
--
ALTER TABLE `panne`
  ADD PRIMARY KEY (`noPanne`),
  ADD KEY `numFourn` (`numFourn`),
  ADD KEY `CodeMateriel` (`CodeMateriel`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `materiel`
--
ALTER TABLE `materiel`
  ADD CONSTRAINT `materiel_ibfk_1` FOREIGN KEY (`numFourn`) REFERENCES `fournisseur` (`numFourn`),
  ADD CONSTRAINT `materiel_ibfk_2` FOREIGN KEY (`CodeCentre`) REFERENCES `centre` (`CodeCentre`),
  ADD CONSTRAINT `materiel_ibfk_3` FOREIGN KEY (`CodeFamille`) REFERENCES `famille` (`CodeFamille`);

--
-- Contraintes pour la table `panne`
--
ALTER TABLE `panne`
  ADD CONSTRAINT `panne_ibfk_1` FOREIGN KEY (`numFourn`) REFERENCES `fournisseur` (`numFourn`),
  ADD CONSTRAINT `panne_ibfk_2` FOREIGN KEY (`CodeMateriel`) REFERENCES `materiel` (`CodeMateriel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
