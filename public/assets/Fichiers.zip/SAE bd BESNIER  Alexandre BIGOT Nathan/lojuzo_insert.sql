INSERT INTO `centre` (`CodeCentre`, `NomCentre`) VALUES
('AD', 'Administratif'),
('DE', 'Découpe'),
('MO', 'Montage'),
('SC', 'Scillage');

INSERT INTO `famille` (`CodeFamille`, `NomFamille`) VALUES
(1, 'Ponceuses'),
(2, 'Raboteuses'),
(3, 'Fraiseuses'),
(4, 'Bureautique');

INSERT INTO `fournisseur` (`numFourn`, `telFour`, `rueFour`, `cpFour`, `villeFour`, `nomFour`) VALUES
(4010123, '0436637823', ' 23 rue du sabot', 71390, 'Ste Hélène', 'SIREX SA'),
(4010245, ' 0559263158', 'Zone artisanale des Mottins', 33000, 'Bordeaux', 'POTTIN');

INSERT INTO `materiel` (`CodeMateriel`, `NomMateriel`, `DateAchat`, `PrixAchat`, `DureeGarantie`, `CodeCentreUtilisateur`, `numFourn`, `CodeCentre`, `CodeFamille`) VALUES
('B0123', 'SCHOB 3852', '2022-01-12 00:00:00', 6895, 2, 'DE, MO', 4010123, 'DE', 2),
('B0126', 'MILANO 4256', '2022-02-05 00:00:00', 8030, 4, 'DE', 4010245, 'DE', 3),
('B0129', 'MILANO 4276', '2022-11-05 00:00:00', 9887, 4, 'DE', 4010245, 'DE', 3);


INSERT INTO `panne` (`noPanne`,`numFourn`, `CodeMateriel`, `DatePanne`, `Nature`, `Montant`, `DateReparation`) VALUES
(1,4010123, 'B0123', '2022-05-05 00:00:00', 'Lame', 25, '2022-05-12 00:00:00'),
(2,4010245, 'B0123', '2022-10-10 00:00:00', 'Courroie', 296, '2022-11-23 00:00:00');

